<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title><?= BASE_NAME ?> - <?= isset($title) ? $title : 'Panel' ?></title>
    <?= $this->renderSection('css') ?>

    <?= link_tag('assets/css/natacode.css') ?>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>

<style>
* {
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background: #f8f9fa;
    margin: 0;
    min-height: 100vh;
}

.prince-container {
    min-height: calc(100vh - 140px);
    padding: 20px 0;
}

/* Modern card styling */
.card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    overflow: hidden;
}

.card-header {
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%) !important;
    color: white !important;
    border: none;
    padding: 20px 24px;
    font-weight: 600;
    font-size: 16px;
}

.card-body {
    padding: 24px;
}

/* Form styling */
.form-control, .form-select {
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 12px 16px;
    background: #f8fafc;
    transition: all 0.2s ease;
    font-size: 14px;
}

.form-control:focus, .form-select:focus {
    border-color: #8b5cf6;
    background: white;
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    outline: none;
}

.form-label {
    font-weight: 500;
    color: #374151;
    margin-bottom: 8px;
}

/* Button styling */
.btn {
    border-radius: 8px;
    font-weight: 500;
    padding: 12px 20px;
    transition: all 0.2s ease;
}

.btn-outline-dark, .btn-outline-warning, .btn-outline-primary, .btn-outline-success {
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    color: white;
    border: none;
}

.btn-outline-dark:hover, .btn-outline-warning:hover, .btn-outline-primary:hover, .btn-outline-success:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
    color: white;
}

/* Table styling */
.table {
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #e2e8f0;
}

.table th {
    background: #f8fafc;
    border: none;
    padding: 16px;
    font-weight: 600;
    color: #374151;
    font-size: 14px;
}

.table td {
    border: none;
    padding: 16px;
    vertical-align: middle;
    border-bottom: 1px solid #f1f5f9;
}

/* Alert styling */
.alert {
    border: none;
    border-radius: 12px;
    padding: 16px 20px;
    margin-bottom: 20px;
}

.alert-primary {
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    color: white;
}

.alert-success {
    background: #dcfce7;
    color: #166534;
    border-left: 4px solid #22c55e;
}

.alert-danger {
    background: #fef2f2;
    color: #dc2626;
    border-left: 4px solid #ef4444;
}

.alert-warning {
    background: #fefce8;
    color: #ca8a04;
    border-left: 4px solid #eab308;
}

/* Badge styling */
.badge {
    padding: 6px 12px;
    border-radius: 6px;
    font-weight: 500;
}

.text-success {
    color: #22c55e !important;
}

.text-danger {
    color: #ef4444 !important;
}

.text-warning {
    color: #f59e0b !important;
}

.text-dark {
    color: #374151 !important;
}

/* Navigation improvements */
.navbar {
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Footer improvements */
footer {
    background: white !important;
    border-top: 1px solid #e2e8f0;
    color: #6b7280 !important;
}

/* List group styling */
.list-group-item {
    border: none;
    border-bottom: 1px solid #f1f5f9;
    padding: 16px 20px;
}

.list-group-item:last-child {
    border-bottom: none;
}

/* Dark mode support */
.dark-mode {
    background: #1f2937;
    color: white;
}

.dark-mode .card {
    background: #374151;
    color: white;
}

.dark-mode .form-control, .dark-mode .form-select {
    background: #4b5563;
    border-color: #6b7280;
    color: white;
}

.dark-mode .table th {
    background: #4b5563;
    color: white;
}

.dark-mode .table td {
    border-color: #4b5563;
}

/* Responsive improvements */
@media (max-width: 768px) {
    .prince-container {
        padding: 10px;
    }
    
    .card-body {
        padding: 16px;
    }
    
    .card-header {
        padding: 16px;
    }
}
</style>
<body>
    <!-- Start menu -->
    <?= $this->include('Layout/Header') ?>
    <!-- End of menu -->
    <main>
        <div class="container prince-container">
            <!-- Start content -->
            <?= $this->renderSection('content') ?>
            <!-- End of content -->
        </div>
    </main>
    <footer class="bg-white border-top py-3">
        <div class="container">
            <small class="text-muted">&copy; <?= date('Y') ?> - <?= BASE_NAME ?></small>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.0/sweetalert2.all.min.js" integrity="sha512-0UUEaq/z58JSHpPgPv8bvdhHFRswZzxJUT9y+Kld5janc9EWgGEVGfWV1hXvIvAJ8MmsR5d4XV9lsuA90xXqUQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <?= script_tag('assets/js/natacode.js') ?>

    <?= $this->renderSection('js') ?>

</body>

</html>