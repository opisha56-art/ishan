<?php

include('conn.php');
include('mail.php');
include('UserMail.php');

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);

// For Keys count
$sql = "SELECT COUNT(*) as id_keys FROM keys_code";
$result = mysqli_query($conn, $sql);
$keycount = mysqli_fetch_assoc($result);

// For Active Keys count
$sql = "SELECT COUNT(devices) as devices FROM keys_code";
$result = mysqli_query($conn, $sql);
$active = mysqli_fetch_assoc($result);

// For In-Active Keys Count
$sql = "SELECT COUNT(*) as devices FROM keys_code where devices IS NULL";
$result = mysqli_query($conn, $sql);
$inactive = mysqli_fetch_assoc($result);

// For Users Count
$sql = "SELECT COUNT(*) as id_users FROM users";
$result = mysqli_query($conn, $sql);
$users = mysqli_fetch_assoc($result);

$userid = session()->userid;
$sql = "SELECT `expiration_date` FROM `users` WHERE `id_users` = '".$userid."'";
$query = mysqli_query($conn, $sql);
$period = mysqli_fetch_assoc($query);

function HoursToDays($value)
{
    if($value == 1) {
       return "$value Hour";
    } else if($value >= 2 && $value < 24) {
       return "$value Hours";
    } else if($value == 24) {
       $darkespyt = $value/24;
       return "$darkespyt Day";
    } else if($value > 24) {
       $darkespyt = $value/24;
       return "$darkespyt Days";
    }
}

$dateTime = strtotime($period['expiration_date']);
$getDateTime = date("F d, Y H:i:s", $dateTime);
?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    @import 'https://fonts.googleapis.com/css?family=Nova+Mono|Eczar';
    
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .dashboard-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .dashboard-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .dashboard-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .dashboard-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 16px;
        padding: 25px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        border-left: 4px solid #8B5CF6;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .stat-header {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin-right: 15px;
    }
    
    .stat-icon.primary {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        color: white;
    }
    
    .stat-icon.success {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .stat-icon.warning {
        background: linear-gradient(135deg, #F59E0B, #D97706);
        color: white;
    }
    
    .stat-icon.danger {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        color: white;
    }
    
    .stat-title {
        font-size: 0.9rem;
        color: #6B7280;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .stat-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1F2937;
        margin: 0;
    }
    
    .expiration-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        margin-bottom: 30px;
        border: 2px solid #8B5CF6;
    }
    
    .expiration-header {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 20px;
    }
    
    .expiration-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.8rem;
        margin-right: 15px;
    }
    
    .expiration-title {
        font-size: 1.5rem;
        font-weight: 700;
        color: #1F2937;
        margin: 0;
    }
    
    #exp {
      font-family: 'Nova Mono', monospace;
        font-size: 2.5rem;
        font-weight: 700;
        color: #8B5CF6;
        text-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
        margin: 0;
    }
    
    .details-card {
        background: white;
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        margin-bottom: 30px;
        overflow: hidden;
    }
    
    .card-header-modern {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 20px 25px;
        font-size: 1.2rem;
        font-weight: 600;
        display: flex;
        align-items: center;
    }
    
    .card-header-modern i {
        margin-right: 10px;
        font-size: 1.3rem;
    }
    
    .modern-list {
        padding: 0;
        margin: 0;
    }
    
    .modern-list-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 25px;
        border-bottom: 1px solid #F3F4F6;
        transition: all 0.3s ease;
    }
    
    .modern-list-item:last-child {
        border-bottom: none;
    }
    
    .modern-list-item:hover {
        background: #F9FAFB;
    }
    
    .list-label {
        font-weight: 600;
        color: #374151;
        display: flex;
        align-items: center;
    }
    
    .list-label i {
        margin-right: 8px;
        color: #8B5CF6;
    }
    
    .modern-badge {
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .badge-success {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }
    
    .badge-danger {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        color: white;
    }
    
    .badge-primary {
        background: linear-gradient(135deg, #3B82F6, #2563EB);
        color: white;
    }
    
    .badge-dark {
        background: linear-gradient(135deg, #6B7280, #4B5563);
        color: white;
    }
    
    .table-modern {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .table-modern table {
        margin: 0;
        border: none;
    }
    
    .table-modern th {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 15px;
        font-weight: 600;
    }
    
    .table-modern td {
        border: none;
        padding: 15px;
        border-bottom: 1px solid #F3F4F6;
    }
    
    .table-modern tr:hover {
        background: #F9FAFB;
    }
    
    .history-badge {
        padding: 6px 12px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .info-card {
        background: white;
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    
    /* Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in {
        animation: fadeInUp 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes pulse {
        0% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.05);
        }
        100% {
            transform: scale(1);
        }
    }
    
    .stat-card:hover .stat-icon {
        animation: pulse 0.6s ease-in-out;
    }
    
    @keyframes glow {
        0% {
            text-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
        }
        50% {
            text-shadow: 0 0 30px rgba(139, 92, 246, 0.6);
        }
        100% {
            text-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
        }
    }
    
    #exp {
        animation: glow 2s ease-in-out infinite;
    }
    
    @media (max-width: 768px) {
        .dashboard-container {
            padding: 15px;
        }
        
        .dashboard-title {
            font-size: 2rem;
        }
        
        .stats-grid {
            grid-template-columns: 1fr;
        }
        
        #exp {
            font-size: 1.8rem;
        }
        
        .expiration-card {
            padding: 25px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="dashboard-container">
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <h1 class="dashboard-title">Prince Panel Dashboard</h1>
        <p class="dashboard-subtitle">Welcome back! Here's your account overview</p>
    </div>
    
    <!-- Status Messages -->
<div class="row">
        <div class="col-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div> 
    </div>
    
    <!-- Statistics Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon primary">
                    <i class="bi bi-key-fill"></i>
              </div>
                <div>
                    <div class="stat-title">Total Keys</div>
                    <h3 class="stat-value"><?php echo $keycount['id_keys']; ?></h3>
             </div>
        </div>
    </div>
    
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon success">
                    <i class="bi bi-check-circle-fill"></i>
              </div>
                <div>
                    <div class="stat-title">Used Keys</div>
                    <h3 class="stat-value"><?php echo $active['devices']; ?></h3>
              </div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon warning">
                    <i class="bi bi-clock-fill"></i>
                </div>
                <div>
                    <div class="stat-title">Unused Keys</div>
                    <h3 class="stat-value"><?php echo $inactive['devices']; ?></h3>
                </div>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon danger">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div>
                    <div class="stat-title">Total Users</div>
                    <h3 class="stat-value"><?php echo $users['id_users']; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Expiration Timer -->
    <div class="expiration-card">
        <div class="expiration-header">
            <div class="expiration-icon">
                <i class="bi bi-clock-fill"></i>
            </div>
            <h2 class="expiration-title">Account Expiration</h2>
        </div>
        <p id="exp"></p>
    </div>
    
    <div class="row">
        <!-- Details Card -->
        <div class="col-lg-8">
            <div class="details-card">
                <div class="card-header-modern">
                    <i class="bi bi-bar-chart-fill"></i>
                    Account Details
                </div>
                <div class="card-body p-0">
                    <ul class="modern-list">
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-key-fill"></i>
                                Total Keys
                            </span>
                            <span class="modern-badge badge-success"><?php echo $keycount['id_keys']; ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-check-circle-fill"></i>
                                Used Keys
                            </span>
                            <span class="modern-badge badge-success"><?php echo $active['devices']; ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-clock-fill"></i>
                                Unused Keys
                            </span>
                            <span class="modern-badge badge-danger"><?php echo $inactive['devices']; ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-people-fill"></i>
                                Total Users
                            </span>
                            <span class="modern-badge badge-danger"><?php echo $users['id_users']; ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Information Card -->
        <div class="col-lg-4">
            <div class="info-card">
                <div class="card-header-modern">
                    <i class="bi bi-info-circle-fill"></i>
                    Information
                </div>
                <div class="card-body p-0">
                    <ul class="modern-list">
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-person-badge-fill"></i>
                                Role
                            </span>
                            <span class="modern-badge badge-dark"><?= getLevel($user->level) ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-wallet-fill"></i>
                                Balance
                            </span>
                            <span class="modern-badge badge-primary">₹<?= $user->saldo ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-clock-history"></i>
                                Login Time
                            </span>
                            <span class="modern-badge badge-dark"><?= $time::parse(session()->time_since)->humanize() ?></span>
                        </li>
                        <li class="modern-list-item">
                            <span class="list-label">
                                <i class="bi bi-stopwatch-fill"></i>
                                Auto Logout
                            </span>
                            <span class="modern-badge badge-dark"><?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- History Table -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="table-modern">
                <div class="card-header-modern">
                    <i class="bi bi-clock-history"></i>
                    History
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Info</th>
                                <th>Details</th>
                                <th>Duration</th>
                                <th>Devices</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $h) : ?>
                                <?php $in = explode("|", $h->info) ?>
                                <tr>
                                    <td><span class="history-badge badge-dark">#3812<?= $h->id_history ?></span></td>
                                    <td><?= $in[0] ?></td>
                                    <td><span class="history-badge badge-dark"><?= $in[1] ?>**</span></td>
                                    <td><span class="history-badge badge-primary"><?= HoursToDays($in[2]); ?></span></td>
                                    <td><span class="history-badge badge-success"><?= $in[3] ?> Devices</span></td>
                                    <td><span class="history-badge badge-dark"><?= $time::parse($h->created_at)->humanize() ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="https://code.jquery.com/jquery-3.1.0.min.js" integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s=" crossorigin="anonymous"></script>
  <script>
    // Modern Countdown Timer
      var countDownTimer = new Date("<?php echo "$getDateTime"; ?>").getTime();
    
        // Update the count down every 1 second
        var interval = setInterval(function() {
            var current = new Date().getTime();
            var diff = countDownTimer - current;
        
            // Countdown Time calculation for days, hours, minutes and seconds
            var days = Math.floor(diff / (1000 * 60 * 60 * 24));
            var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((diff % (1000 * 60)) / 1000);

        // Format the countdown display
        var timeString = '';
        if (days > 0) {
            timeString += days + (days === 1 ? ' Day ' : ' Days ');
        }
        if (hours > 0) {
            timeString += hours + 'h ';
        }
        if (minutes > 0) {
            timeString += minutes + 'm ';
        }
        timeString += seconds + 's';

        document.getElementById("exp").innerHTML = timeString;
        
            // Display Expired, if the count down is over
            if (diff < 0) {
                clearInterval(interval);
                document.getElementById("exp").innerHTML = "EXPIRED";
            document.getElementById("exp").style.color = "#EF4444";
            }
        }, 1000);
    
    // Add smooth animations to stat cards
    document.addEventListener('DOMContentLoaded', function() {
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('animate-fade-in');
        });
    });
</script>
<?= $this->endSection() ?>