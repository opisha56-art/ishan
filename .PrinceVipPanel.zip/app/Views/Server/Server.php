<?php
include('conn.php');
include('mail.php');

// for maintainece mode
$sql1 ="select * from onoff where id=1";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1);

// for ftext and status
$sql2 ="select * from _ftext where id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2);

// for Features Status
$sql3 = "SELECT * FROM Feature WHERE id=1";
$result3 = mysqli_query($conn, $sql3);
$ModFeatureStatus = mysqli_fetch_assoc($result3);

?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .server-container {
        padding: 20px;
        min-height: 100vh;
    }
    
    .server-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
    }
    
    .server-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .server-subtitle {
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    .server-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 30px;
        transition: all 0.3s ease;
    }
    
    .server-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .server-card-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        padding: 25px 30px;
        font-size: 1.3rem;
        font-weight: 600;
        display: flex;
        align-items: center;
    }
    
    .server-card-header i {
        margin-right: 12px;
        font-size: 1.5rem;
    }
    
    .server-card-body {
        padding: 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
        display: block;
    }
    
    .form-control, .form-select {
        width: 100%;
        padding: 15px 20px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #F9FAFB;
    }
    
    .form-control:focus, .form-select:focus {
        outline: none;
        border-color: #8B5CF6;
        background: white;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    }
    
    .modern-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px;
        background: #F9FAFB;
        border-radius: 12px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }
    
    .modern-toggle:hover {
        background: #F3F4F6;
    }
    
    .toggle-label {
        font-weight: 600;
        color: #374151;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .toggle-label i {
        color: #8B5CF6;
        font-size: 1.2rem;
    }
    
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 30px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 30px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 22px;
        width: 22px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    
    input:checked + .toggle-slider {
        background: linear-gradient(135deg, #8B5CF6, #7C3AED);
    }
    
    input:focus + .toggle-slider {
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2);
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(30px);
    }
    
    .status-info {
        background: #F3F4F6;
        padding: 15px;
        border-radius: 12px;
        margin-bottom: 20px;
        font-size: 0.9rem;
        color: #6B7280;
    }
    
    .status-info strong {
        color: #374151;
    }
    
    .update-btn {
        width: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 15px;
        border-radius: 12px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .update-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    
    .update-btn.danger {
        background: linear-gradient(135deg, #EF4444, #DC2626);
    }
    
    .update-btn.danger:hover {
        box-shadow: 0 10px 20px rgba(239, 68, 68, 0.3);
    }
    
    .update-btn.warning {
        background: linear-gradient(135deg, #F59E0B, #D97706);
    }
    
    .update-btn.warning:hover {
        box-shadow: 0 10px 20px rgba(245, 158, 11, 0.3);
    }
    
    .update-btn.success {
        background: linear-gradient(135deg, #10B981, #059669);
    }
    
    .update-btn.success:hover {
        box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3);
    }
    
    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }
    
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
        margin-bottom: 25px;
    }
    
    .current-status {
        background: linear-gradient(135deg, #F3F4F6, #E5E7EB);
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 25px;
        border-left: 4px solid #8B5CF6;
    }
    
    .current-status h6 {
        color: #374151;
        font-weight: 600;
        margin-bottom: 10px;
    }
    
    .current-status .status-item {
        display: inline-block;
        background: white;
        padding: 4px 12px;
        border-radius: 20px;
        margin: 2px;
        font-size: 0.85rem;
        font-weight: 500;
    }
    
    .current-status .status-on {
        color: #059669;
        background: #D1FAE5;
    }
    
    .current-status .status-off {
        color: #DC2626;
        background: #FEE2E2;
    }
    
    @media (max-width: 768px) {
        .server-container {
            padding: 15px;
        }
        
        .server-title {
            font-size: 2rem;
        }
        
        .server-card-body {
            padding: 20px;
        }
        
        .feature-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="server-container">
    <!-- Server Header -->
    <div class="server-header">
        <h1 class="server-title">Server Management</h1>
        <p class="server-subtitle">Configure server settings and mod features</p>
    </div>
    
    <!-- Status Messages -->
    <div class="row">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>
    
    <div class="row">
        <!-- Maintenance Mode Card -->
        <?php if($user->level != 2) : ?>
        <div class="col-lg-6">
            <div class="server-card">
                <div class="server-card-header">
                    <i class="bi bi-tools"></i>
                    Server Maintenance
                </div>
                <div class="server-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="status_form" value="1">
                    
                    <div class="status-info">
                        <strong>Current Status:</strong> 
                        <span class="badge <?= $userDetails1['status'] == 'on' ? 'bg-danger' : 'bg-success' ?>">
                            <?= ucfirst($userDetails1['status']) ?>
                        </span>
                    </div>
                    
                    <div class="modern-toggle">
                        <div class="toggle-label">
                            <i class="bi bi-shield-exclamation"></i>
                            Maintenance Mode
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="radios" id="radio" value="on" <?= $userDetails1['status'] == "on" ? 'checked' : '' ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    
                    <div class="form-group">
                        <label for="myInput" class="form-label">Offline Message</label>
                        <div class="status-info">
                            <strong>Current Message:</strong> <?= $userDetails1['myinput'] ?>
                        </div>
                        <textarea class="form-control" placeholder="Server is under maintenance" name="myInput" id="myInput" rows="3"></textarea>
                        <?php if ($validation->hasError('myInput')) : ?>
                            <span class="error-message"><?= $validation->getError('myInput') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="update-btn">
                        <i class="bi bi-arrow-clockwise"></i>
                        Update Settings
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!-- Mod Features Card -->
        <div class="col-lg-6">
            <div class="server-card">
                <div class="server-card-header">
                    <i class="bi bi-gear-fill"></i>
                    Mod Features
                </div>
                <div class="server-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="feature_form" value="1">
                    
                    <div class="current-status">
                        <h6>Current Feature Status</h6>
                        <span class="status-item <?= $ModFeatureStatus['ESP'] == 'on' ? 'status-on' : 'status-off' ?>">ESP: <?= ucfirst($ModFeatureStatus['ESP']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['Item'] == 'on' ? 'status-on' : 'status-off' ?>">Items: <?= ucfirst($ModFeatureStatus['Item']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['AIM'] == 'on' ? 'status-on' : 'status-off' ?>">AIM: <?= ucfirst($ModFeatureStatus['AIM']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['SilentAim'] == 'on' ? 'status-on' : 'status-off' ?>">SilentAim: <?= ucfirst($ModFeatureStatus['SilentAim']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['BulletTrack'] == 'on' ? 'status-on' : 'status-off' ?>">BulletTrack: <?= ucfirst($ModFeatureStatus['BulletTrack']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['Memory'] == 'on' ? 'status-on' : 'status-off' ?>">Memory: <?= ucfirst($ModFeatureStatus['Memory']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['Floating'] == 'on' ? 'status-on' : 'status-off' ?>">Floating: <?= ucfirst($ModFeatureStatus['Floating']) ?></span>
                        <span class="status-item <?= $ModFeatureStatus['Setting'] == 'on' ? 'status-on' : 'status-off' ?>">Setting: <?= ucfirst($ModFeatureStatus['Setting']) ?></span>
                    </div>
                    
                    <div class="feature-grid">
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-eye-fill"></i>
                                ESP
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="ESP" id="ESP" value="on" <?= $ModFeatureStatus['ESP'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-box-fill"></i>
                                Items
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="Item" id="Item" value="on" <?= $ModFeatureStatus['Item'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-crosshair"></i>
                                Aim-Bot
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="AIM" id="AIM" value="on" <?= $ModFeatureStatus['AIM'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-bullseye"></i>
                                Silent Aim
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="SilentAim" id="SilentAim" value="on" <?= $ModFeatureStatus['SilentAim'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-arrow-right-circle-fill"></i>
                                Bullet Track
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="BulletTrack" id="BulletTrack" value="on" <?= $ModFeatureStatus['BulletTrack'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-cpu-fill"></i>
                                Memory
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="Memory" id="Memory" value="on" <?= $ModFeatureStatus['Memory'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-chat-text-fill"></i>
                                Floating Texts
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="Floating" id="Floating" value="on" <?= $ModFeatureStatus['Floating'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        
                        <div class="modern-toggle">
                            <div class="toggle-label">
                                <i class="bi bi-sliders"></i>
                                Settings
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="Setting" id="Setting" value="on" <?= $ModFeatureStatus['Setting'] == "on" ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="update-btn danger">
                        <i class="bi bi-arrow-clockwise"></i>
                        Update Features
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        <!-- Change Mod Name Card -->
        <div class="col-lg-6">
            <div class="server-card">
                <div class="server-card-header">
                    <i class="bi bi-pencil-square"></i>
                    Change Mod Name
                </div>
                <div class="server-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="modname_form" value="1">
                    
                    <div class="status-info">
                        <strong>Current Mod Name:</strong> <?php echo $row['modname']; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="modname" class="form-label">New Mod Name</label>
                        <input type="text" name="modname" id="modname" class="form-control" placeholder="Enter your new mod name" required>
                        <?php if ($validation->hasError('modname')) : ?>
                            <span class="error-message"><?= $validation->getError('modname') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="update-btn warning">
                        <i class="bi bi-arrow-clockwise"></i>
                        Update Mod Name
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        
        <!-- Change Floating Text Card -->
        <div class="col-lg-6">
            <div class="server-card">
                <div class="server-card-header">
                    <i class="bi bi-chat-text"></i>
                    Change Floating Text
                </div>
                <div class="server-card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="_ftext" value="1">
                    
                    <div class="status-info">
                        <strong>Current Status:</strong> 
                        <span class="badge <?= $userDetails2['_status'] == 'Safe' ? 'bg-success' : 'bg-warning' ?>">
                            <?= ucfirst($userDetails2['_status']) ?>
                        </span>
                    </div>
                    
                    <div class="modern-toggle">
                        <div class="toggle-label">
                            <i class="bi bi-shield-check"></i>
                            Safe Mode
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="_ftextr" id="_ftextr" value="Safe" <?= $userDetails2['_status'] == "Safe" ? 'checked' : '' ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    
                    <div class="form-group">
                        <label for="_ftext" class="form-label">Floating Text</label>
                        <div class="status-info">
                            <strong>Current Text:</strong> <?php echo $userDetails2['_ftext']; ?>
                        </div>
                        <input type="text" name="_ftext" id="_ftext" class="form-control" placeholder="Give feedback else key removed!" required>
                        <?php if ($validation->hasError('_ftext')) : ?>
                            <span class="error-message"><?= $validation->getError('_ftext') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="update-btn success">
                        <i class="bi bi-arrow-clockwise"></i>
                        Update Floating Text
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>