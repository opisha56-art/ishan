<?php

namespace App\Models;

use CodeIgniter\Model;

class Server extends Model
{
    /*=================================================================*/
    
    protected $table      = 'modname';
    protected $allowedFields = ['modname'];
    
}